-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2023 at 12:14 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `name`, `email`, `password`) VALUES
(1, 'abhi', 'abhi123@gmail.com', 'abhi123'),
(2, 'vivo', 'v@gmail.com', 'v'),
(3, '', '', ''),
(4, 'x', 'x@gmail.com', 'x');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `des` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `des`) VALUES
(33, 'Science & Technology', ''),
(34, 'World', ''),
(35, 'Sports', ''),
(36, 'Politics', ''),
(37, 'Buisness', '');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `fname` longtext NOT NULL,
  `lname` longtext NOT NULL,
  `subject` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `fname`, `lname`, `subject`) VALUES
(1, 'abhi', 'shinde', 'sdfghj'),
(2, 'di', '', 'dk'),
(3, 'di', '', 'dk'),
(4, 'di', '', 'dk'),
(5, 'abhi', 'abhi', 'abhi'),
(6, 'abhi', 'abhi', 'abhi'),
(7, 'abhi', 'abhi', 'abhi');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `des` longtext NOT NULL,
  `date` date NOT NULL,
  `category` varchar(300) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `news_buisness`
--

CREATE TABLE `news_buisness` (
  `id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `des` longtext NOT NULL,
  `date` date NOT NULL,
  `category` varchar(300) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news_buisness`
--

INSERT INTO `news_buisness` (`id`, `title`, `des`, `date`, `category`, `thumbnail`) VALUES
(7, 'GST collection for April highest ever at Rs 1.87 lakh crore', 'The GST collection grew by 12 per cent in April, the highest since the rollout of the indirect tax regime.\r\nBy Press Trust of India: GST collection grew by 12 per cent in April to Rs 1.87 lakh crore, the highest monthly mop-up since the rollout of the indirect tax regime.\r\n\r\nThe gross GST revenue collected in the month of April 2023 is Rs 1,87,035 crore of which CGST is Rs 38,440 crore, SGST is Rs 47,412 crore, IGST is Rs 89,158 crore (including Rs 34,972 crore collected on import of goods) and cess is Rs 12,025 crore, the finance ministry said in a statement.', '2023-05-01', '', 'nirmala_sitharaman-sixteen_nine.avif'),
(8, 'KredX receives final approval from IFSCA to facilitate cross-border trade finance', 'KredX GTX Aims to execute over $500 million by the end of 2023 and an overall $2 billion worth of transactions in the next 18 months.\r\nThe International Financial Services Centres Authority (IFSCA) has granted the final approval to the supply chain financing platform KredX to facilitate global trade for Indian businesses through its International trade financing platform KredX GTX.\r\n\r\n“We are the first ones to receive the final approval in India…we are now a registered entity under IFSCA. This is a very big milestone for us and for the entire trade financing ecosystem. This will further boost the export push by the government,” said Anurag Jain, Founder & Executive Director at KredX.\r\n\r\nIn 2021 GIFT-City and IFSCA came out with guidelines on rolling out a platform called International Trade Financing Services (ITFS) for Global Trade financing enabled through tech platforms for exporters and importers through a commercial licence. KredX was one of the applicants of the licence and received an in-principal nod in October of 2022.\r\n\r\n', '2023-05-02', '', 'exportsimports-770x433.webp'),
(9, 'RBI likely buying dollars to absorb inflows: Traders', 'The Indian rupee was trading at 81.8275 per U.S. dollar, having reached 81.7325 earlier.\r\nThe Indian central bank is likely buying dollars via state-run banks to prevent the rupee from appreciating in the wake of inflows, three traders told Reuters on Tuesday.\r\n\r\nThe Indian rupee was trading at 81.8275 per U.S. dollar, having reached 81.7325 earlier.\r\n\r\nThe long weekend inflows and the dollar offers from foreign banks are \"once again running into a resolute\" Reserve Bank of India (RBI), a trader at private sector bank said.\r\n\r\nThe state-run banks have been consistently on the bid since morning and it is \"difficult to put it down to anything\" other than the RBI, another trader said.', '2023-05-02', '', 'RBI-770x433.avif');

-- --------------------------------------------------------

--
-- Table structure for table `news_politics`
--

CREATE TABLE `news_politics` (
  `id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `des` text NOT NULL,
  `date` date NOT NULL,
  `category` int(30) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news_politics`
--

INSERT INTO `news_politics` (`id`, `title`, `des`, `date`, `category`, `thumbnail`) VALUES
(4, 'Hard decisions and reforms are needed to improve farm productivity', 'Low farm productivity makes farmers vulnerable to market fluctuations. Besides, they fail to produce enough to meet steadily growing market demand and end up with lower incomes\r\nAmidst the looming threats of El Nino, the forecast of a normal monsoon by the Indian Meteorological Department brings cheers to a country wherein half of the gross-cropped area relies on unpredictable monsoon rains.\r\n\r\nHowever, what matters is not the total amount of rainfall but its spatial and temporal distribution. Besides, whether we have a normal or below normal monsoon, that does not address the long-standing problem of low farm productivity which calls for a multi-pronged strategy that focuses on region-specific challenges instead of a one-size-fits-all approach that characterises India’s agriculture policy.\r\n\r\nTo significantly improve crop productivity, farmers must grow crops suited to local climatic and soil conditions. However, the existing system of assured procurement at prices fixed by the government comes in the way, in a macroeconomic environment increasingly influenced by regulatory adhocism and political populism aimed at retaining the electoral support of rural voters.', '2023-05-02', 0, 'Farmer-winnowing-wheat-grains-from-the-chaff-in-traditional-way-770x433.jpg'),
(5, 'Petrol, diesel price 2 May 2023: Check out changed fuel rates here!', 'Petrol-diesel price 2 May 2023:: It has been 345th days in a row that Indian oil companies have not raised the price of petrol and diesel. The price of petrol and diesel has remained unchanged on Tuesday, i.e. May 2, 2023. It is really a relief for common man amid the high inflation rate across the globe.  The steady price of fuel has brought respite among the public.\r\n\r\nPeople get relief in inflation period where price of every commodity is increasing, price of petrol and diesel remain stable. Public sector oil marketing companies (OMC) such as Bharat Petroleum Corporation Ltd (BPCL), Indian Oil Corporation Ltd, and Hindustan Petroleum Corporation Ltd (HPCL) released their pricing on a daily basis in accordance following global benchmark prices.\r\n\r\nThe price of crude oil on the worldwide market has decreased.  Crude has dropped to $78 per barrel, while Brent Crude is now at $85 per barrel.\r\n\r\nOn Tuesday, the price of petrol is Rs 106.31 per liter in Mumbai, Rs 106.03 in Kolkata, Rs 96.72 in New Delhi, and Rs 102.63 in Chennai. It is again a relief for the common people.', '2023-05-02', 0, 'petrol-rate-April-3.webp');

-- --------------------------------------------------------

--
-- Table structure for table `news_science`
--

CREATE TABLE `news_science` (
  `id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `des` longtext NOT NULL,
  `date` date NOT NULL,
  `category` varchar(300) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news_science`
--

INSERT INTO `news_science` (`id`, `title`, `des`, `date`, `category`, `thumbnail`) VALUES
(6, 'AI-guided drones are opening a new future for farming', 'Many US farmers are now turning away from tractors and toward AI-guided precision drones with computer vision to adapt to the rising cost of chemicals, hotter temperatures, heavier rains, heartier weeds and prolific pests\r\nEarly one recent morning in Vidalia, Georgia, third-generation farmer Greg Morgan launched an AG-230 drone carrying eight gallons of fungicide over a field of sweet onions. The chemical, which is essential to crop survival in this humid state, would typically be dragged and dripped from a 500-gallon tank behind Morgan’s 10,000-pound tractor. Now it fell in a fine mist from the spray jets of an 80-pound drone scudding 10 feet above his cash crop.\r\n\r\nVidalia Onions are a $150 million local industry that, like peaches, tomatoes and other specialty crops in the Southeast, have become increasingly vulnerable to climate change. Morgan has joined the vanguard of farmers who are turning away from tractors and toward drones as they adapt to the rising cost of chemicals and contend with hotter temperatures, heavier rains, heartier weeds and prolific pests.\r\n\r\nFarmers have been using drones over the past 20 years mainly for aerial imaging  scanning farms from the sky with cameras to map where crops are thriving and failing. Now drones are being designed for hands-on crop management: enabled to spray herbicides, insecticides and foliar fertilizer with precision, and even to distribute seeds in planting season.', '2023-05-01', '', 'drone-770x433.avif'),
(7, 'Amazon skips India update, warns of slowdown in global cloud business', 'Amazon has already shut units like Amazon Food in India and also announced that Amazon Academy would be closed down in a phased manner, starting August 2023\r\nGlobal e-commerce giant Amazon, which skipped any mention of its performance in India, said the growth in its cloud computing business has slowed as companies cut back spending in a tough macroeconomic environment.\r\n\r\nIn the January-March quarter, Amazon Web Services (AWS), which accounts for a bulk of the Seattle-based company’s revenue, saw its operating income fall 21 percent year-on- year (YoY) from $6.5 billion in Q1 2022 to $5.1 billion.\r\n\r\nThe unit’s net sales, however, grew 16 percent YoY from $18.4 billion in Q1 2022 to $21.4 billion in Q1 2023, beating analysts’ estimates.\r\n\r\nOver the past months, Amazon CEO Andrew Jassy announced a series of job cuts, with employees at AWS being the latest to be affected.', '2023-04-28', '', 'amazon-shut-down-featured--580x435.avif'),
(8, 'Artificial Intelligence could spell the end of big business', 'Today more Americans work for big companies than for small ones. But AI could change that given how leading companies in the field like Mid journey having just 11 and Open AI just 375 full time employees\r\nBig business has been a fixture of American life since the late 19th century, and today more Americans work for big companies than for small ones. That could be about to change — in part because of the rise of artificial intelligence.\r\n\r\nConsider the most prestigious service that generates images using AI, a company called Mid journey. It has a total of 11 full-time employees. Perhaps more are on the way, but that is remarkably few workers for a company that is becoming widely known in its field.\r\n\r\nPart of the trick, of course, is that a lot of the work is done by computers and artificial intelligence. I don’t think this will lead to mass unemployment, because history shows that workers have typically managed to move from automating sectors into new and growing ones. But if some of the new job-creating sectors are personal services such as elder care, those jobs are typically in smaller and more local firms. That means fewer Americans working for big business.\r\n\r\nOr consider Chat GPT, which has been described as the most rapidly growing consumer technology product in history. It is produced by Open AI, headquartered in San Francisco. By one recent estimate the company has about 375 employees. By contrast, Meta, even after some layoffs, currently has more than 60,000.', '2023-04-26', '', 'chat.avif'),
(9, 'WhatsApp is working on Instagram-like broadcast channels', 'The new feature will allow users to broadcast information and sign up for updates from people they follow.\r\nWhatsApp is working on an Instagram-like broadcast feature that allows users to display information and receive updates from accounts they choose to follow.\r\n\r\nThe feature was discovered by WA-Beta-Info in the latest iOS beta build for the Meta-owned instant messaging service. WhatsApp will rename the Status tab to Updates as it will serve as a hub for both status and broadcast channel information.', '2023-04-24', '', 'whatsapp.avif'),
(10, 'x', 'x', '2023-05-08', '', 'Shreyas-Iyer-undergoes-back-surgery.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `news_sports`
--

CREATE TABLE `news_sports` (
  `id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `des` longtext NOT NULL,
  `date` date NOT NULL,
  `category` varchar(300) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news_sports`
--

INSERT INTO `news_sports` (`id`, `title`, `des`, `date`, `category`, `thumbnail`) VALUES
(3, 'Shreyas Iyer undergoes back surgery, likely to return before ODI World Cup 2023', 'New Delhi: India’s middle over mainstays Shreyas Iyer has completed his surgery in London, United Kingdom on Tuesday. He is set to return to cricketing action for the One-Day International (ODI) World Cup 2023 in India, scheduled to take place during October-November this year.\r\n\r\nIyer set to miss WTC final\r\nShreyas Iyer, who was ruled out of the action after he suffered a back injury during Gavaskar Trophy (BGT) 2023 against Australia. The injury forced him out of the series after playing just 2 days of the fourth Test vs Australia. This injury forced him to miss the entirety of the ongoing IPL 2023, and also the World Test Championship (WTC) Final.\r\n\r\nAs per the media report, Iyer would need a minimum of 3 months to recover from the surgery and regain full fitness.', '2023-04-21', '', 'Shreyas-Iyer-undergoes-back-surgery.jpg'),
(4, 'WTC 2023 Final: Team India’s squad announced; Ajinkya Rahane makes sensational comeback after IPL heroics', 'WTC Final 2023: The BCCI announced the Indian team for the World Test Championship final on Tuesday, led by Rohit Sharma. Team India must face Australia in the title match at the Oval in England. Ajinkya Rahane has been reinstated in the team. Shardul Thakur has also been named in the 15-man squad.\r\n\r\nThe World Test Championship final will take place from June 9 to June 13, 2023. Australia has already announced its squad for this. Five fast bowlers have been included in the Indian team’s lineup, according to the pitch of England. Simultaneously, Suryakumar Yadav has been handed the way out.\r\n\r\nAjinkya Rahane’s dazzling form in IPL 2023\r\nAjinkya Rahane is seen in fantastic rhythm while playing for Chennai Super Kings in the Indian Premier League 2023. This IPL season, he has scored 209 runs in five innings. His strike rate is also higher than 155 percent. Rahane had previously batted successfully in domestic cricket.', '2023-04-25', '', 'Indian-Test-Team.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `news_world`
--

CREATE TABLE `news_world` (
  `id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `des` longtext NOT NULL,
  `date` date NOT NULL,
  `category` varchar(300) NOT NULL,
  `thumbnail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news_world`
--

INSERT INTO `news_world` (`id`, `title`, `des`, `date`, `category`, `thumbnail`) VALUES
(7, 'Delhi government launches summer action plan to curb air pollution', 'New Delhi, May 1 (PTI) Delhi Chief Minister Arvind Kejriwal on Monday launched an action plan to combat air pollution during the summer months with a focus on controlling dust pollution.\r\n\r\nThe Delhi government already has a winter action plan to curb air pollution. The winter plan focuses on stubble burning, firecracker pollution and industrial and vehicular emissions.\r\n\r\nThe summer plan involves the participation of 30 government departments. The primary focus of the action plan is on dust pollution, which has been a major contributor to the city’s worsening air quality, Kejriwal said during a press conference.\r\n\r\n“To tackle this, the government has procured 84 mechanical road sweeping machines, 609 water sprinklers and 185 mobile anti-smog guns. Additionally, 70 integrated road sweeping machines and 250 integrated water sprinklers are being procured to improve the situation further,” he said.\r\n\r\nPatrolling teams have been set up to check dust pollution, open burning of garbage and dumping of waste in industrial areas.\r\n\r\nThe government will deploy 225 and 159 teams during days and nights, respectively, to monitor dust pollution in the city.\r\n\r\nReal-time source apportionment studies will be conducted at 13 air pollution hotspots and a mobile air lab deployed at each of these locations.\r\n\r\nConstruction sites larger than 500 square metres will be closely monitored to check dust pollution.\r\n\r\nThe government has prepared a standard operating procedure to prevent fire incidents at landfill sites. A plan is also being prepared for the scientific disposal of industrial waste, the chief minister said.\r\n\r\nKejriwal added that a special team is being set up to improve the survival rate of transplanted trees.\r\n\r\nThe chief minister also claimed that Delhi’s air pollution situation is improving while it continues to worsen in other parts of the country.\r\n\r\nAir pollution has come down by 30 per cent between 2016 and 2022 and the number of severe air quality days declined from 26 in 2016 to just six in 2022, he said. PTI GVS SZM\r\n\r\n', '2023-05-01', '', 'download (1).jpg'),
(8, 'Bird Flu detectives hunt for clues to stop next global pandemic', 'A rapid response team of local health workers was dispatched within hours to the village, a two hour drive from the capital Phnom Penh. They found a community of almost 2,000 people living in brightly colored wooden and sheet metal homes, close to their livestock and chickens.\r\nIf you want to know how the world is preparing for the next global pandemic look at Rolaing, a Cambodian village located on a tributary of the Mekong River. For a few days in February this isolated spot became a hive of public health activity after an 11-year-old girl died of H5N1, the most virulent strain of bird flu — the country’s first fatality from the disease since 2014.\r\n\r\nA rapid response team of local health workers was dispatched within hours to the village, a two hour drive from the capital Phnom Penh. They found a community of almost 2,000 people living in brightly colored wooden and sheet metal homes, close to their livestock and chickens.\r\n\r\n', '2023-05-02', '', '397838348-770x433.avif'),
(9, 'Meta Platforms raises $8.5 billion in second-ever bond sale', 'The social-media behemoth, which reported earnings last week, raised $8.5 billion in a five-part deal, according to a person familiar with the matter. The longest portion of the offering, a 40-year security, yields 192 basis points over Treasuries, less than initial discussions for about 215 basis points.\r\nMeta Platforms Inc. emerged as the first mega-cap technology company to tap the US investment-grade bond market amid turmoil in the financial sector that has toppled five banks since March.\r\nThe social-media behemoth, which reported earnings last week, raised $8.5 billion in a five-part deal, according to a person familiar with the matter. The longest portion of the offering, a 40-year security, yields 192 basis points over Treasuries, less than initial discussions for about 215 basis points.\r\n\r\n\r\n', '2023-05-02', '', 'Collage-Maker-22-Mar-2023-02-31-PM-6671-770x433.avif'),
(11, 'Tech groupthink could hinder AI competition', 'Everyone wants a piece of OpenAI, the startup behind artificial intelligence-powered chatbot ChatGPT. After raising $10 billion from technology giant Microsoft, the company has raked in another $300 million from venture capital’s leading lights, including Andreessen Horowitz and Sequoia Capital, TechCrunch reported. Its competitors may struggle to find backers with deep enough pockets to help them unseat the reigning leader.\r\n\r\nWhile some startup investors, like fellow OpenAI backer Tiger Global, sometimes fund direct competitors, the practice is generally frowned upon in an industry built on maintaining friendly relationships to score early access to hot deals. Sequoia relinquished its stake in payments firm Finix over concerns it competed with existing portfolio company Stripe.\r\n\r\n', '2023-05-02', '', 'AI-770x433.avif'),
(12, 'xy', 'xy', '2023-05-08', '', 'Farmer-winnowing-wheat-grains-from-the-chaff-in-traditional-way-770x433.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'hi', 'abhi123@gmail.com', '$2y$10$CJmI8q19wB1NdXeYZTs9dOUoEnDqt1bzew04K7EVPPjpNw4D5/JCS'),
(2, 'abhi@gmail.com', 'abhi1@gmail.com', '1'),
(3, 'abhi@gmail.com', 'abhi1@gmail.com', '1'),
(4, 'a', 'a@gmail.com', 'abhi123'),
(5, 'abc123', 'abc123@gmail.com', 'abc'),
(6, 'abhi123@gmail.com', '', 'abhi123'),
(7, 'abhi123@gmail.com', '', 'abhi123'),
(8, 'abhi', 'ab1@gmail.com', 'a'),
(9, 'a', 'a12@gmail.com', 'a'),
(10, 'a', 'a@gmail.com', 'a'),
(11, 'abc', 'abc@gmail.com', 'abc'),
(12, 'x', 'x@gmail.com', 'x');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_buisness`
--
ALTER TABLE `news_buisness`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_politics`
--
ALTER TABLE `news_politics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_science`
--
ALTER TABLE `news_science`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_sports`
--
ALTER TABLE `news_sports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_world`
--
ALTER TABLE `news_world`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `news_buisness`
--
ALTER TABLE `news_buisness`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `news_politics`
--
ALTER TABLE `news_politics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news_science`
--
ALTER TABLE `news_science`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `news_sports`
--
ALTER TABLE `news_sports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news_world`
--
ALTER TABLE `news_world`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
