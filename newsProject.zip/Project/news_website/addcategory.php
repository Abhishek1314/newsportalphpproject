<?php
session_start();
error_reporting(0);

if(!isset($_SESSION['email'])){
    header("location:admin_login.php");
}
?>

<?php
 include('include/header.php');
 ?>

<div class="container">
    
<form action="addcategory.php" method="post" name="categoryform" onsubmit="return validform()">
    <h1>Add Category</h1>
  <div class="form-group">
    <label for="email">Category:</label>
    <input type="text" name="category" class="form-control"  id="email">
  </div>
  <div class="form-group">
  <label for="comment">Description:</label>
  <textarea class="form-control" name="des"  rows="5" id="comment"></textarea>
</div>
  <input type="submit" class="btn btn-primary" name="submit" value="Add categories">
</form>
</div>

<script>
  function validform(){
    var x = document.forms['categoryform']['category'].value;
    if(x==""){
      alert('category must be fill out');
      return false;
    }

  }
</script>


<?php
include('db/connection.php');
if (isset($_POST['submit'])){
  $category_name=$_POST['category'];
  $des=$_POST['des'];

  $check=mysqli_query($conn, "select * from category where category_name='$category_name'");
  if(mysqli_num_rows($check)>0){
    echo "<script> alert('category name allready exist')</script>";
    exit();

  }

  $query=mysqli_query($conn,"INSERT INTO `category` ( `category_name`, `des`) VALUES ( '$category_name', '$des')");
  if($query){
    echo "<script> alert('cattegory add')</script>";
  }
  else{
    echo "<script> alert('try again')</script>";
  }
}



?>