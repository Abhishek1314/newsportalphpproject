<?php
session_start();
error_reporting(0);

if(!isset($_SESSION['email'])){
    header("location:login.php");
}
?>


<!doctype html>
<html lang="en" data-bs-theme="">
  <head><script src="/docs/5.3/assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.111.3">
    <title>News Portal</title>

 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/5.3/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/5.3/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/5.3/assets/img/favicons/safari-pinned-tab.svg" color="#712cf9">
<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon.ico">
<meta name="" content="">


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }
      .bd-mode-toggle {
        z-index: 1500;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="style/blog.css" rel="stylesheet">
  </head>


  <body>
   
    

  <div class="container">
  <header class="blog-header lh-1 py-3">
    <div class="row flex-nowrap justify-content-between align-items-center">
      <div class="col-4 pt-1">
        <a class="link-secondary" href="#">Subscribe</a>
      </div>
      <div class="col-4 text-center">
        <a class="blog-header-logo text-body-emphasis" href="#">News Portal</a>
      </div>
      <div class="col-4 d-flex justify-content-end align-items-center">
        <div class="dropdown">
          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">User</button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a href="login.php" class="dropdown-item">Login & SignUp</a>
            <a href="userlogout.php" class="dropdown-item">Logout</a>
          </div>
        </div>
      </div> 
    </div>
  </header>

  <div class="nav-scroller py-1 mb-2">
    <nav class="nav d-flex justify-content-between">
      <a class="p-2 link-secondary" href="index.php">Home</a>
      <a class="p-2 link-secondary" href="world.php">World</a>
      <a class="p-2 link-secondary" href="science.php">Science & Technology</a>
      <a class="p-2 link-secondary" href="buisness.php">Business</a>
      <a class="p-2 link-secondary" href="politics.php">Politics</a>
      <a class="p-2 link-secondary" href="sports.php">Sports</a>
    </nav>
  </div>
</div>

<main class="container">
  
  <div class="p-4 p-md-5 mb-4 rounded text-bg-dark">

  

  </div>
  

  
  
  <div class="row g-5">
    <div class="col-md-8">
      <h3 class="pb-4 mb-4 fst-italic border-bottom">
        Todays News
      </h3>
   <?php
   include('db/connection.php');
   $query=mysqli_query($conn, "select * from news_politics");
   
   while($row=mysqli_fetch_array($query)){

   
   ?>

      <article class="blog-post">
        <h4 class="blog-post-title mb-1"><a href="politics_page.php?single=<?php echo $row['id']; ?>"><?php echo $row['title']; ?></a></h4>
        <p class="blog-post-meta"><?php echo $row['date'];?><a href="#"></a></p>

        <p><img class="img img-thumbnail" src="images/<?php echo $row['thumbnail']; ?>" style="height:10%" alt=""></p>
        <hr>
        <blockquote class="blockquote">
          <?php echo substr($row['des'],0,300); ?>
          <button class="btn  btn-sm"> <a href="politics_page.php?single=<?php echo $row['id']; ?>"><?php  $row['title']; ?>Read More</a></button>
        </blockquote>
         </article>
      
<?php
   }
   ?> 





  
           


    </div>

    <div class="col-md-4">
      <div class="position-sticky" style="top: 2rem;">
        <div class="p-4 mb-3 bg-body-tertiary rounded">
          <h4 class="fst-italic">About</h4>
          <hr>
          <p class="mb-0">Welcome to News Portal, your one-stop source for all the latest news and updates. We're dedicated to providing you with the most accurate and up-to-date news, as well as in-depth analysis and expert opinion on a wide range of topics. </p>
          <p class="mb-0">Our team of experienced journalists and editors are committed to delivering high-quality news content that informs, educates and entertains our readers. We cover everything from breaking news and politics to business, sports and world.</p>
                </div>

        <div class="p-4">
          <h4 class="fst-italic">Category</h4>
          <hr>
          <ol class="list-unstyled mb-0">
            <?php
            include('db/connection.php');
            $query1=mysqli_query($conn, " select * from category");
            while($row=mysqli_fetch_array($query1)){

            
            ?>
            <li><a href="category_page.php?single=<?php echo $row['category_name']; ?>"><?php echo $row['category_name']; ?></a></li>
           <?php } ?>
          </ol>
        </div>

        <div class="p-4">
          <h4 class="fst-italic">Archives</h4>
          <ol class="list-unstyled mb-0">
            <li><a href="#">March 2021</a></li>
            <li><a href="#">February 2021</a></li>
            <li><a href="#">January 2021</a></li>
            <li><a href="#">December 2020</a></li>
            <li><a href="#">November 2020</a></li>
            <li><a href="#">October 2020</a></li>
            <li><a href="#">September 2020</a></li>
            <li><a href="#">August 2020</a></li>
            <li><a href="#">July 2020</a></li>
            <li><a href="#">June 2020</a></li>
            <li><a href="#">May 2020</a></li>
            <li><a href="#">April 2020</a></li>
          </ol>
        </div>

        
      </div>
    </div>
  </div>

</main>

<?php
include('include/footer.php');
?>


    
  </body>
</html>
