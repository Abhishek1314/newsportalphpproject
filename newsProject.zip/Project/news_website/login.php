<?php
session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style/admin.css">
</head>
<body>
    <div class="container">
        <style>
            .container {
  max-width: 500px;
  margin: 50px auto;
  padding: 30px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #fff;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

        </style>
        <form action="login.php" method="post">
            <h2>Login</h2>
            <hr>
  <div class="form-group">
    <label for="email">Email address:</label>
    <br>
    <input type="email" class="form-control" placeholder="Enter email" name="email" id="email">
    
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <br>
    <input type="password" class="form-control" name="password" placeholder="Enter password" id="pwd">
    
  </div>
  <input type="submit" class="btn btn-primary" name="submit" value="Login">
  <a href="signup.php">SignUp</a>
</form>
    </div>
</body>
</html>

<?php
include('db/connection.php');

if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $password=$_POST['password'];

    $query=mysqli_query($conn, "select * from users where email='$email' AND password='$password'");
    if($query){
        if(mysqli_num_rows($query)>0){
            $_SESSION['email']=$email;
            header('location:index.php');
        }
        else{
            echo "<script> alert('Try Again...!')</script>";
        }
    }

}
?>