<?php
session_start();
error_reporting(0);

if(!isset($_SESSION['email'])){
    header("location:admin_login.php");
}
?>

<?php
    include('include/header.php');
    error_reporting(0);
    

 ?>
<?php
include('db/connection.php');
$id=$_GET['edit'];
$query=mysqli_query($conn, "select * from news where id = '$id'");
while($row=mysqli_fetch_array($query)){
    $id=$row['id'];
    $title=$row['title'];
    $des=$row['des'];
    $date=$row['date'];
    $thumbnail=$row['thumbnail'];
    $category=$row['category'];
    
}
?>



<div class="container">
    <div>
        <ul class="breadcrumb">
        <li class="breadcrumb-item active"><a href="home.php">home</a></li>
            <li class="breadcrumb-item active"><a href="news.php">news</a></li>
            <li class="breadcrumb-item active">Add news</li>
        </ul>
    </div>
    
<form action="news_edit.php" method="post" name="categoryform" enctype="multipart/form-data" onsubmit="return validform()">
    <h1>Update News</h1>
  <div class="form-group">
    <label for="email">Title:</label>
    <input type="text" name="title" class="form-control" value="<?php echo $title; ?>" id="email">
  </div>
  
  <div class="form-group">
  <label for="comment">Description:</label>
  <textarea class="form-control" name="des" value="<?php echo $des; ?>" rows="5" id="comment"><?php echo $des; ?></textarea>
</div>
<div class="form-group">
    <label for="email">Date:</label>
    <input type="date" name="date" class="form-control" value="<?php echo $date; ?>"  id="email">
  </div>
  <div class="form-group">
    <label for="email">Thumbnail:</label>
    <input type="file" name="thumbnail" class="form-control img-thumbnail" value="<?php echo $thumbnail; ?>" id="email">
    <img src="images/<?php echo $thumbnail; ?>" alt="" width="200px" height="200px" class="img img-thumbnail">
  </div>
  <input type="hidden" name="id" value="<?php echo $date; ?>">
  <div class="form-group">
    <label for="email">Category:</label>
    <select name="category" id="" value="<?php echo $category; ?>" class="form-control">
        <?php
        include('db/connection.php');
        $query=mysqli_query($conn, "select * from category");
        while($row=mysqli_fetch_array($query)){
            $category=$row['category_name'];
            ?>
        
        <option value=""><?php echo $row['category_name']; ?></option>
     <?php } ?>
    </select>
  </div>
  <input type="submit" class="btn btn-primary" name="submit" value="Update">
</form>
</div>

<script>
  function validform(){
    var x = document.forms['categoryform']['title'].value;
    var y = document.forms['categoryform']['des'].value;
    if(x==""){
      alert('title must be fill out');
      return false;
    }
    if(y==""){
      alert('description must be fill out');
      return false;
    }
    if(y.legth<100){
      alert('description at least 100 characters must be fill out');
      return false;
    }
  }
</script>


<?php
include('db/connection.php');
if(isset($_POST)){
  $id=$_POST['id'];
  $title=$_POST['title'];
  $des=$_POST['des'];
  $date=$_POST['date'];
  $thumbnail=$_FILES['thumbnail']['name'];
  $tmp_thumbnail=$_FILES['thumbnail']['tmp_name'];
  move_uploaded_file($tmp_thumbnail, "images/$thumbnail");
  $category=$_POST['category'];
    $sql=mysqli_query($conn, "update news set title='$title',des='$des',date='$date',category='$category' where id='$id'");
    if($sql){
      echo "<script> alert('edited sucess')</script>";

    }
    else{
        echo "category not update";
    }
}

?>