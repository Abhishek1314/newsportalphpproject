<?php
session_start();
error_reporting(0);

if(!isset($_SESSION['email'])){
    header("location:admin_login.php");
}
?>


<?php
    include('include/header.php');
 ?>

<div class="container">
    <div>
        <ul class="breadcrumb">
        <li class="breadcrumb-item active"><a href="home.php">home</a></li>
            <li class="breadcrumb-item active"><a href="world_news.php">news</a></li>
            <li class="breadcrumb-item active">Add news</li>
        </ul>
    </div>
    
<form action="addworld_news.php" method="post" name="categoryform" enctype="multipart/form-data" onsubmit="return validform()">
    <h1>Add News</h1>
  <div class="form-group">
    <label for="email">Title:</label>
    <input type="text" name="title" class="form-control"  id="email">
  </div>
  
  <div class="form-group">
  <label for="comment">Description:</label>
  <textarea class="form-control" name="des"  rows="5" id="comment"></textarea>
</div>
<div class="form-group">
    <label for="email">Date:</label>
    <input type="date" name="date" class="form-control"  id="email">
  </div>
  <div class="form-group">
    <label for="email">Thumbnail:</label>
    <input type="file" name="thumbnail" class="form-control img-thumbnail"  id="email">
  </div>
  
  <input type="submit" class="btn btn-primary" name="submit" value="Add News">
</form>
</div>

<script>
  function validform(){
    var x = document.forms['categoryform']['title'].value;
    var y = document.forms['categoryform']['des'].value;
    if(x==""){
      alert('title must be fill out');
      return false;
    }
    if(y==""){
      alert('description must be fill out');
      return false;
    }
    if(y.legth<100){
      alert('description at least 100 characters must be fill out');
      return false;
    }
  }
</script>


<?php
include('db/connection.php');
if(isset($_POST['submit'])){
  $title=$_POST['title'];
  $des=$_POST['des'];
  $date=$_POST['date'];
  $thumbnail=$_FILES['thumbnail']['name'];
  $tmp_thumbnail=$_FILES['thumbnail']['tmp_name'];
  move_uploaded_file($tmp_thumbnail, "images/$thumbnail");
  $category=$_POST['category'];



  $query1=mysqli_query($conn, "insert into news_world(title,des,date,category,thumbnail)values('$title','$des','$date','$category','$thumbnail')");
  if($query1){
    echo "<script>alert('news uploaded sucessfully')</script>";
  }
  else{
    echo "<script>alert('please try again')</script>";
  }
}

?>