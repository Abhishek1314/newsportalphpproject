<?php
session_start();
error_reporting(0);

if(!isset($_SESSION['email'])){
    header("location:admin_login.php");
}
?>

<?php
 include('include/header.php'); 
 error_reporting(0);
?>

<div class="container">
<div>
        <ul class="breadcrumb">
        <li class="breadcrumb-item active"><a href="home.php">home</a></li>
            <li class="breadcrumb-item active">news</li>

        </ul>
    </div>
    <div class="text-right">
        <button class="btn"><a href="addsports_news.php">Add news</a></button>
    </div>

<table class="table table-bordered">
    <tr>
        <th>id</th>
        <th>title</th>
        <th>description</th>
        <th>date</th>

        <th>thumbnail</th>
        
        <th>delete</th>
    </tr>
    <?php
    include('db/connection.php');
    $page=$_GET['page'];
    if($page==0 || $page==1){
        $page1=0;
    }
    else{
        $page1=($page*3)-3;
    }
    $query=mysqli_query($conn, "select * from news_sports limit $page1,5");
    while($row=mysqli_fetch_array($query)){
    ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['title']; ?></td>
        <td><?php echo substr($row['des'],0,60);?></td>
        <td><?php echo date("F jS ,y", strtotime($row['date'])); ?></td>
    
        <td><img class="img img-thumbnail" src="images/<?php echo $row['thumbnail']; ?>" alt="" width="150" height="150"></td>
        
        <td><a href="news_delete.php?del=<?php echo $row['id'];?>" class="btn btn-danger">delete</a></td>

    </tr>
    

    <?php } ?>
    
    </table>
    <ul class="pagination">
        <li class="page-item">
            <a href="#" class="page-link disabled">previous</a>
        </li>
    <?php
    $sql=mysqli_query($conn, "select * from news_sports");
    $count=mysqli_num_rows($sql);
    $a=$count/3;
    ceil($a);
    for($b=1; $b <$a; $b++){
        ?>

        <li class="page-item"><a class="page-link" href="sports.php?page=<?php echo $b; ?>">
        <?php echo $b; ?></a></li>

        <?php  
    } 
    ?>
    <li class="page-item">
            <a href="#" class="page-link disabled">next</a>
        </li>
    </ul>
</div>
