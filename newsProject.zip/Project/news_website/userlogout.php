<?php
session_start();
session_unset();
header('location:../news_website/login.php');
?>