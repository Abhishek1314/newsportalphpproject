<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
    padding: top 50px;
    
    width:500px;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px 30px 40px;
  margin-left:500px;
}
</style>

<div class="container">
    
<form action="contact_us.php" method="post" name="contactform" onsubmit="return validform()">
    <h1>Contact Us</h1>
  <div class="form-group">
    <label for="email">First Name:</label>
    <input type="text" name="fname" class="form-control"  id="email">
  </div>
  <div class="form-group">
  <label for="comment">Last Name:</label>
  <input type="text" name="lname" class="form-control"  id="email">
</div>
  <div class="form-group">
  <label for="comment">Subject:</label>
  <textarea class="form-control" name="subject"  rows="5" id="comment"></textarea>
</div>
  <input type="submit" class="btn btn-primary" name="submit" value="Send Message....">
</form>
</div>

<script>
  function validform(){
    var x = document.forms['contactform']['subject'].value;
    if(x==""){
      alert('subject must be fill out');
      return false;
    }

  }
</script>
</div>

<?php
include('db/connection.php');
if(isset($_POST['submit'])){
  $fname=$_POST['fname'];
  $lname=$_POST['lname'];
  $subject=$_POST['subject'];
  


  $query3=mysqli_query($conn, "insert into contact_us(fname,lname,subject)values('$fname','$lname','$subject')");
  if($query3){
    echo "<script>alert('Message Send Sucessfully....!')</script>";
  }
  else{
    echo "<script>alert('Please Try Again....!')</script>";
  }
}

?>