<?php
session_start();
error_reporting(0);

if(!isset($_SESSION['email'])){
    header("location:admin_login.php");
}
?>

<?php
include('include/header.php');
?>



<div class="container">
  <style>
    body{
    font-family:Arial, sans-serif;
    background-color:#f0f0f0;
    color:#333;
    }
    h1{
      text-align:center;
      margin-top:50px;
    }
    p{
      font-size: 20px;
      line-height:1.5;
      margin:30px;

    }
  </style>
<h1> Welcome to our Website</h1>
<p>Thank you for visiting our website. We hope you find the information you`re looking for.</p>

</div>