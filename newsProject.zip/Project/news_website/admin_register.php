<?php
session_start();
error_reporting(0);

if(isset($_SESSION['email'])){
    header("location:home.php");
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style/admin.css">
</head>
<body>
    <div class="container">
    <style>
            .container {
  max-width: 500px;
  margin: 50px auto;
  padding: 30px;
  border: 1px solid #ccc;
  border-radius: 10px;
  background-color: #fff;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

        </style>
        <form action="admin_register.php" method="post">
            <h2>Admin Registeration</h2>
            <div class="form-group">
    <label for="email">Name</label>
    <input type="text" class="form-control" placeholder="Enter name" name="name" id="text">
  </div>

  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" placeholder="Enter email" name="email" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" name="password" placeholder="Enter password" id="pwd">
  </div>
  <input type="submit" class="btn btn-primary" name="submit" value="Signup">
</form>
    </div>
</body>
</html>



<?php
include('db/connection.php');
if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $email=$_POST['email'];
  $password=$_POST['password'];
  


  $query1=mysqli_query($conn, "insert into admin_login(name,email,password)values('$name','$email','$password')");
  if($query1){
    echo "<script>alert('Registeration  Sucessful...!')</script>";
    header('location:admin_login.php');

  }
  else{
    echo "<script>alert('Try Again...!')</script>";
  }
}

?>