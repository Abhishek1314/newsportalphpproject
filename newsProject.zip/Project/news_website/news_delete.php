<?php
session_start();
error_reporting(0);

if(!isset($_SESSION['email'])){
    header("location:admin_login.php");
}
?>

<?php
include('db/connection.php');
$id=$_GET['del'];
$query=mysqli_query($conn, "delete from news where id='$id'");

if($query){
    echo  "<script> alert('News Has Been Deleted....!')</script>";
    echo "<script>window.location='http://localhost/news_website/home.php';</script>";

}
else{
    echo  "<script> alert('Please Try Again.....!')</script>";
}

?>
<?php
include('db/connection.php');
$id=$_GET['del'];
$query=mysqli_query($conn, "delete from news_world where id='$id'");

if($query){
    echo  "<script> alert('News Has Been Deleted....!')</script>";
    echo "<script>window.location='http://localhost/news_website/home.php';</script>";

}
else{
    echo  "<script> alert('Please Try Again.....!')</script>";
}

?>

<?php
include('db/connection.php');
$id=$_GET['del'];
$query=mysqli_query($conn, "delete from news_politics where id='$id'");

if($query){
    echo  "<script> alert('News Has Been Deleted....!')</script>";
    echo "<script>window.location='http://localhost/news_website/home.php';</script>";

}
else{
    echo  "<script> alert('Please Try Again.....!')</script>";
}

?>


<?php
include('db/connection.php');
$id=$_GET['del'];
$query=mysqli_query($conn, "delete from news_buisness where id='$id'");

if($query){
    echo  "<script> alert('News Has Been Deleted....!')</script>";
    echo "<script>window.location='http://localhost/news_website/home.php';</script>";

}
else{
    echo  "<script> alert('Please Try Again.....!')</script>";
}

?>

<?php
include('db/connection.php');
$id=$_GET['del'];
$query=mysqli_query($conn, "delete from news_science where id='$id'");

if($query){
    echo  "<script> alert('News Has Been Deleted....!')</script>";
    echo "<script>window.location='http://localhost/news_website/home.php';</script>";

}
else{
    echo  "<script> alert('Please Try Again.....!')</script>";
}

?>

<?php
include('db/connection.php');
$id=$_GET['del'];
$query=mysqli_query($conn, "delete from news_sports where id='$id'");

if($query){
    echo  "<script> alert('News Has Been Deleted....!')</script>";
    echo "<script>window.location='http://localhost/news_website/home.php';</script>";

}
else{
    echo  "<script> alert('Please Try Again.....!')</script>";}
?>

<?php
include('db/connection.php');
$id=$_GET['del'];
$query=mysqli_query($conn, "delete from category where id='$id'");

if($query){
    echo  "<script> alert('Category Has Been Deleted.....!')</script>";
    echo "<script>window.location='http://localhost/news_website/home.php';</script>";
}
else{
    echo  "<script> alert('Please Try Again.....!')</script>";
}

?>